import java.sql.*;
import javax.swing.JOptionPane;
public class Citizen {
    ConnectionToDB con=new ConnectionToDB();
    Connection con_obj=con.EstablishConnection();
    Statement stmt=null;//used for insert, update & delete
    PreparedStatement pstmt=null;//used for select
    ResultSet res=null;
    
    String name,Cnic,Age,Uname,Upass;
    
    public boolean LoginUser(String chkuser,String chkpass){
        //select * from Table_Name where Column1='"+value+"'and Column2='"+value+"'....Col_n='"+value+"';
        String loginString="select * from CitizenData where UName='"+chkuser+"'and UPass='"+chkpass+"'";
        boolean b;
        try{
            pstmt=con_obj.prepareStatement(loginString);
            res=pstmt.executeQuery();
            if(res.next()){
                b=true;
            }
            else{
                b=false;
            }
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null, ex);
            b=false;
        }
        return b;
    }
    
    public boolean CheckEligibility(int age,int cnic){
        boolean b;
        if(age>=18){
            String chkElig="select * from CitizenData where CNIC='"+cnic+"'";
            try{
                pstmt=con_obj.prepareStatement(chkElig);
                res=pstmt.executeQuery();
                if(res.next()){
                    b=false;
                }
                else{
                    b=true;
                }
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null, ex);
                b=false;
            }
        }
        else{
            b=true;
        }
        return b;
    }
    //New citizen registration
    public boolean createCitizen(String name,int cnic,int age,String uname,String upass){
        boolean b=false;
        //insert into Table_Name(Column1,Column2,...,Col_n)values('"+var1+"','"+var2+"',...,'"+var_n+"');
        String sql="insert into CitizenData(Cit_Name,CNIC,Age,UName,UPass)values('"+name+"','"+cnic+"','"+age+"','"+uname+"','"+upass+"')";
        try{
            stmt=con_obj.createStatement();
            int res=stmt.executeUpdate(sql);
            if(res>0){
                //JOptionPane.showMessageDialog(null, "Inserted");
                b=true;
            }
            else{
                //JOptionPane.showMessageDialog(null, "Error");
                b=false;
            }
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null, ex);
        }
        return b;
    }
    //Check if voting is open or closed
    public boolean CheckVotingOpen(){
        boolean voting;
        String chkVotOpen="select * from AdminData where ID='"+1+"'";
        try{
            pstmt=con_obj.prepareStatement(chkVotOpen);
            res=pstmt.executeQuery();
            if(res.next()){
                voting=res.getBoolean("Voting_Open");
            }
            else{
                voting=true;
            }
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null, ex);
            voting=false;
        }
        return voting;
    }
    //Check if citizen has already voted or not
    public boolean chkVotedORNot(int cnic){
        boolean voted;
        String chkVotedOrNot="select * from CitizenData where CNIC='"+cnic+"'";
        try{
            pstmt=con_obj.prepareStatement(chkVotedOrNot);
            res=pstmt.executeQuery();
            if(res.next()){
                voted=res.getBoolean("Voted");
            }
            else{
                voted=true;
            }
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null, ex);
            voted=false;
        }
        return voted;
    }
    
    public boolean voteCasted(int cnic){
        boolean pass;
        String updateVotedOrNot="UPDATE CitizenData SET Voted='"+true+"' WHERE CNIC='"+cnic+"'";
        try{   
            stmt=con_obj.createStatement();
            int res=stmt.executeUpdate(updateVotedOrNot);
            if(res>0){
                //JOptionPane.showMessageDialog(null, "Updated");
                pass=true;
            }
            else{
                //JOptionPane.showMessageDialog(null, "Error");
                pass=false;
            }
        }
        catch(Exception ex){
           JOptionPane.showMessageDialog(null, ex);
           pass=false;
        }
        return pass;
    }
    
    //change password of candidate
    public boolean changePassword(String user,String oldPass, String newPass){
        String change="select * from CitizenData where UName='"+user+"'and UPass='"+oldPass+"'";
        boolean b;
        try{
            pstmt=con_obj.prepareStatement(change);
            res=pstmt.executeQuery();
            if(res.next()){
                b=true;
            }
            else{
                b=false;
            }
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null, ex);
            b=false;
        }
        change="UPDATE CitizenData SET UPass='"+newPass+"' WHERE UName='"+user+"'";
        try{   
            stmt=con_obj.createStatement();
            int res=stmt.executeUpdate(change);
            if(res>0){
                //JOptionPane.showMessageDialog(null, "Updated");
                b=true;
            }
            else{
                //JOptionPane.showMessageDialog(null, "Error");
                b=false;
            }
        }
        catch(SQLException ex){
           JOptionPane.showMessageDialog(null, "Error");
           b=false;
        }
        return b;
    }
    
    //search data from database
    public boolean findCandidate(int id){
        boolean b = false;
        
        String sql = "select* from CitizenData where ID = '"+id+"'";
        try{
            pstmt = con_obj.prepareStatement(sql);
            res = pstmt.executeQuery();
            while(res.next()){
                name = res.getString("Can_Name");
                Cnic = res.getString("CNIC");
                Age = res.getString("Age");
                Uname = res.getString("UName");
                Upass = res.getString("UPass");

                b= true;
            }                     
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "NO Record Found");
        }
        return b;
    }
    
    //delete record from admin
    public boolean deleteRecord(int id){
        boolean b=false;
        //delete from Table_Name where ID='"+id+"';
        String sql="delete from CitizenData where ID='"+id+"'";
        try{
            stmt=con_obj.createStatement();
            int res=stmt.executeUpdate(sql);
            if(res>0){
                JOptionPane.showMessageDialog(null, "Deleted");
                b=true;
            }
            else{
                JOptionPane.showMessageDialog(null, "Error");
                b=false;
            }
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null, ex);
        }
        return b;
    }
    
    //account check for candidate dashboard
    public boolean accountCheck(int cnic){
        String cnicCheck="select* from CitizenData where CNIC='"+cnic+"'";
        boolean b;
        try{
            pstmt=con_obj.prepareStatement(cnicCheck);
            res=pstmt.executeQuery();
            if(res.next()){
                b=true;
            }
            else{
                b=false;
            }
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "NO CNIC Record");
            b=false;
        }
        return b;        
    }
    //update citizen data
    public boolean updateUser(String name,int Cnic,int Age,int id){
        String updateString="UPDATE CitizenData SET Cit_Name='"+name+"',CNIC='"+Cnic+"',Age='"+Age+"' WHERE ID='"+id+"'";
        boolean b=false;
        try{   
            stmt=con_obj.createStatement();
            int res=stmt.executeUpdate(updateString);
            if(res>0){
                //JOptionPane.showMessageDialog(null, "Updated");
                b=true;
            }
            else{
                //JOptionPane.showMessageDialog(null, "Error");
                b=false;
            }
        }
        catch(Exception ex){
           JOptionPane.showMessageDialog(null, "Error");
        }
        return b;
    }
}
