
import java.awt.event.KeyEvent;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class Form_Admin_Dashboard extends javax.swing.JFrame {
    ConnectionToDB con_obj=new ConnectionToDB();
    Admin adm=new Admin();
    Citizen citz=new Citizen();
    Candidate cand = new Candidate();
    Scanner inp = new Scanner(System.in);
    
    public Form_Admin_Dashboard() {
        initComponents();
        con_obj.EstablishConnection();
        table.setVisible(false);
        jScrollPane2.setVisible(false);
        refresh.setVisible(false);
        panelCitizen.setVisible(false);
        tableCitizen.setVisible(false);
        refreshCitizen.setVisible(false);
        tableWin.setVisible(false);
        winnerTable.setVisible(false);
        winnerRefresh.setVisible(false);
        msg1.setVisible(false);
        msg3.setVisible(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        msg2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel3 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        on = new javax.swing.JRadioButton();
        off = new javax.swing.JRadioButton();
        done = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        Ron = new javax.swing.JRadioButton();
        Roff = new javax.swing.JRadioButton();
        rdone = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        cname = new javax.swing.JTextField();
        pname = new javax.swing.JTextField();
        cnic = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        age = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        uname = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        upass = new javax.swing.JTextField();
        btn_add_candidate = new javax.swing.JButton();
        btn_delete_candidate = new javax.swing.JButton();
        btn_update_candidate = new javax.swing.JButton();
        record = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        refresh = new javax.swing.JButton();
        btn_clear_candidate = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        id = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        btn_search_candidate = new javax.swing.JButton();
        msg1 = new javax.swing.JLabel();
        msg3 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        id1 = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        cnic1 = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        age1 = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        uname1 = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        upass1 = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        citname = new javax.swing.JTextField();
        btn_add_citizen = new javax.swing.JButton();
        btn_delete_citizen = new javax.swing.JButton();
        btn_update_citizen = new javax.swing.JButton();
        btn_search_citizen = new javax.swing.JButton();
        btn_clear_citizen = new javax.swing.JButton();
        panelCitizen = new javax.swing.JScrollPane();
        tableCitizen = new javax.swing.JTable();
        record1 = new javax.swing.JButton();
        refreshCitizen = new javax.swing.JButton();
        jLabel21 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        winner = new javax.swing.JButton();
        winnerTable = new javax.swing.JScrollPane();
        tableWin = new javax.swing.JTable();
        winnerRefresh = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        SIGNOUT = new javax.swing.JButton();

        msg2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        msg2.setText("* Numbers (0-9)  and Special Characters are Not Allowed");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(255, 0, 51));

        jTabbedPane2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTabbedPane2.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jTabbedPane2StateChanged(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel5.setText("ONLINE VOTING CONTROL");

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel7.setText("VOTING STATUS");

        on.setText("ON");
        on.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                onActionPerformed(evt);
            }
        });

        off.setText("OFF");
        off.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                offActionPerformed(evt);
            }
        });

        done.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        done.setText("DONE");
        done.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                doneActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(289, 289, 289)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(72, 72, 72)
                                .addComponent(jLabel7))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(422, 422, 422)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(off)
                            .addComponent(on)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(410, 410, 410)
                        .addComponent(done)))
                .addContainerGap(332, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabel5)
                .addGap(18, 18, 18)
                .addComponent(jLabel7)
                .addGap(36, 36, 36)
                .addComponent(on)
                .addGap(18, 18, 18)
                .addComponent(off)
                .addGap(18, 18, 18)
                .addComponent(done)
                .addContainerGap(214, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("VOTING ON / OFF", jPanel3);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel6.setText("ONLINE REGISTRATION CONTROL");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel8.setText("REGISTRATION STATUS");

        Ron.setText("ON");
        Ron.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RonActionPerformed(evt);
            }
        });

        Roff.setText("OFF");
        Roff.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RoffActionPerformed(evt);
            }
        });

        rdone.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        rdone.setText("DONE");
        rdone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdoneActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(349, 349, 349)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(89, 89, 89)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Roff)
                                    .addComponent(Ron)))))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(248, 248, 248)
                        .addComponent(jLabel6))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(420, 420, 420)
                        .addComponent(rdone)))
                .addContainerGap(292, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel6)
                .addGap(18, 18, 18)
                .addComponent(jLabel8)
                .addGap(32, 32, 32)
                .addComponent(Ron)
                .addGap(18, 18, 18)
                .addComponent(Roff)
                .addGap(18, 18, 18)
                .addComponent(rdone)
                .addContainerGap(224, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("REGISTRATION ON/OFF", jPanel4);

        jLabel1.setText("CANDIDATE NAME");

        jLabel2.setText("CANDIDATE PARTY");

        jLabel10.setText("CNIC");

        jLabel11.setText("AGE");

        cname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cnameActionPerformed(evt);
            }
        });
        cname.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                cnameKeyTyped(evt);
            }
        });

        pname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pnameActionPerformed(evt);
            }
        });
        pname.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                pnameKeyTyped(evt);
            }
        });

        cnic.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cnicActionPerformed(evt);
            }
        });
        cnic.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                cnicKeyTyped(evt);
            }
        });

        age.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                ageKeyTyped(evt);
            }
        });

        jLabel13.setText("USER NAME");

        uname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                unameActionPerformed(evt);
            }
        });

        jLabel14.setText("USER PASSWORD");

        btn_add_candidate.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btn_add_candidate.setText("ADD");
        btn_add_candidate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_add_candidateActionPerformed(evt);
            }
        });

        btn_delete_candidate.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btn_delete_candidate.setText("DELETE");
        btn_delete_candidate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_delete_candidateActionPerformed(evt);
            }
        });

        btn_update_candidate.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btn_update_candidate.setText("UPDATE");
        btn_update_candidate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_update_candidateActionPerformed(evt);
            }
        });

        record.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        record.setText("VIEW RECORD");
        record.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                recordMouseClicked(evt);
            }
        });
        record.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                recordActionPerformed(evt);
            }
        });

        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(table);
        if (table.getColumnModel().getColumnCount() > 0) {
            table.getColumnModel().getColumn(0).setResizable(false);
            table.getColumnModel().getColumn(1).setResizable(false);
            table.getColumnModel().getColumn(2).setResizable(false);
            table.getColumnModel().getColumn(3).setResizable(false);
        }

        refresh.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        refresh.setText("REFRESH TABLE");
        refresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refreshActionPerformed(evt);
            }
        });

        btn_clear_candidate.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btn_clear_candidate.setText("CLEAR");
        btn_clear_candidate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_clear_candidateActionPerformed(evt);
            }
        });

        jLabel3.setText("ID");

        id.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                idMouseClicked(evt);
            }
        });
        id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setText("*Optional for Data Entry");

        btn_search_candidate.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btn_search_candidate.setText("SEARCH");
        btn_search_candidate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_search_candidateActionPerformed(evt);
            }
        });

        msg1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        msg1.setText("* Numbers (0-9)  and Special Characters are Not Allowed");

        msg3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        msg3.setText("* Only Numbers (0-9) are Allowed");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(206, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel10)
                    .addComponent(jLabel11)
                    .addComponent(jLabel1)
                    .addComponent(jLabel13)
                    .addComponent(jLabel3)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(btn_add_candidate)
                        .addComponent(jLabel14)))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btn_delete_candidate)
                        .addGap(18, 18, 18)
                        .addComponent(btn_update_candidate)
                        .addContainerGap())
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(record)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(id, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(cname, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(pname, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(upass, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 182, Short.MAX_VALUE)
                                .addComponent(uname, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(age, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(cnic, javax.swing.GroupLayout.Alignment.LEADING)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(btn_search_candidate)
                                        .addGap(18, 18, 18)
                                        .addComponent(btn_clear_candidate))
                                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 247, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(33, 33, 33)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4)
                                    .addComponent(msg1, javax.swing.GroupLayout.PREFERRED_SIZE, 327, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(msg3, javax.swing.GroupLayout.PREFERRED_SIZE, 327, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(131, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(refresh)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 680, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(117, 117, 117))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(jLabel3))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(cname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(pname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(msg1))
                .addGap(6, 6, 6)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(cnic, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(msg3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(age, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(uname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel14)
                            .addComponent(upass, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel11)
                        .addComponent(jLabel12)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_add_candidate)
                    .addComponent(btn_delete_candidate)
                    .addComponent(btn_update_candidate)
                    .addComponent(btn_search_candidate)
                    .addComponent(btn_clear_candidate))
                .addGap(12, 12, 12)
                .addComponent(record)
                .addGap(3, 3, 3)
                .addComponent(refresh)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(47, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("MANAGE CANDIDATE", jPanel1);

        jLabel15.setText("ID");

        id1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                id1MouseClicked(evt);
            }
        });
        id1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                id1ActionPerformed(evt);
            }
        });

        jLabel16.setText("CNIC");

        cnic1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                cnic1KeyTyped(evt);
            }
        });

        jLabel17.setText("AGE");

        age1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                age1KeyTyped(evt);
            }
        });

        jLabel18.setText("USER NAME");

        uname1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                uname1ActionPerformed(evt);
            }
        });

        jLabel19.setText("USER PASSWORD");

        jLabel20.setText("Name");

        citname.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                citnameKeyTyped(evt);
            }
        });

        btn_add_citizen.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btn_add_citizen.setText("ADD");
        btn_add_citizen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_add_citizenActionPerformed(evt);
            }
        });

        btn_delete_citizen.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btn_delete_citizen.setText("DELETE");
        btn_delete_citizen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_delete_citizenActionPerformed(evt);
            }
        });

        btn_update_citizen.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btn_update_citizen.setText("UPDATE");
        btn_update_citizen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_update_citizenActionPerformed(evt);
            }
        });

        btn_search_citizen.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btn_search_citizen.setText("SEARCH");
        btn_search_citizen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_search_citizenActionPerformed(evt);
            }
        });

        btn_clear_citizen.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btn_clear_citizen.setText("CLEAR");
        btn_clear_citizen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_clear_citizenActionPerformed(evt);
            }
        });

        tableCitizen.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                true, true, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        panelCitizen.setViewportView(tableCitizen);
        if (tableCitizen.getColumnModel().getColumnCount() > 0) {
            tableCitizen.getColumnModel().getColumn(0).setResizable(false);
            tableCitizen.getColumnModel().getColumn(1).setResizable(false);
            tableCitizen.getColumnModel().getColumn(2).setResizable(false);
            tableCitizen.getColumnModel().getColumn(3).setResizable(false);
        }

        record1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        record1.setText("VIEW RECORD");
        record1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                record1MouseClicked(evt);
            }
        });
        record1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                record1ActionPerformed(evt);
            }
        });

        refreshCitizen.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        refreshCitizen.setText("REFRESH TABLE");
        refreshCitizen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refreshCitizenActionPerformed(evt);
            }
        });

        jLabel21.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel21.setText("*Optional for Data Entry");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGap(176, 176, 176)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel16)
                                    .addComponent(jLabel17)
                                    .addComponent(jLabel15)
                                    .addComponent(jLabel20)
                                    .addComponent(jLabel18))
                                .addGap(46, 46, 46))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel19)
                                .addGap(18, 18, 18)))
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(id1, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(upass1, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(age1, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cnic1, javax.swing.GroupLayout.DEFAULT_SIZE, 182, Short.MAX_VALUE)
                            .addComponent(citname)
                            .addComponent(uname1))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel21))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(138, 138, 138)
                        .addComponent(btn_add_citizen)
                        .addGap(18, 18, 18)
                        .addComponent(btn_delete_citizen)
                        .addGap(24, 24, 24)
                        .addComponent(btn_update_citizen)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btn_search_citizen)
                        .addGap(18, 18, 18)
                        .addComponent(btn_clear_citizen))
                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(jPanel6Layout.createSequentialGroup()
                            .addGap(277, 277, 277)
                            .addComponent(record1)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(refreshCitizen))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel6Layout.createSequentialGroup()
                            .addGap(70, 70, 70)
                            .addComponent(panelCitizen, javax.swing.GroupLayout.PREFERRED_SIZE, 650, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(100, 100, 100))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(id1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel21)
                    .addComponent(jLabel15))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(citname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel20))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cnic1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(age1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel17))
                .addGap(14, 14, 14)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(uname1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel18))
                .addGap(15, 15, 15)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(upass1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel19))
                .addGap(18, 18, 18)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_add_citizen)
                    .addComponent(btn_delete_citizen)
                    .addComponent(btn_update_citizen)
                    .addComponent(btn_search_citizen)
                    .addComponent(btn_clear_citizen))
                .addGap(12, 12, 12)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(record1)
                    .addComponent(refreshCitizen))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(panelCitizen, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(54, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("MANAGE CITIZEN", jPanel6);

        winner.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        winner.setText("CALCULATE WINNER");
        winner.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                winnerActionPerformed(evt);
            }
        });

        tableWin.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        winnerTable.setViewportView(tableWin);
        if (tableWin.getColumnModel().getColumnCount() > 0) {
            tableWin.getColumnModel().getColumn(0).setResizable(false);
            tableWin.getColumnModel().getColumn(1).setResizable(false);
            tableWin.getColumnModel().getColumn(2).setResizable(false);
            tableWin.getColumnModel().getColumn(3).setResizable(false);
        }

        winnerRefresh.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        winnerRefresh.setText("Refresh Result");
        winnerRefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                winnerRefreshActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(winnerTable, javax.swing.GroupLayout.PREFERRED_SIZE, 709, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(winnerRefresh)))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(267, 267, 267)
                        .addComponent(winner)))
                .addContainerGap(186, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(winner)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(winnerRefresh)
                .addGap(18, 18, 18)
                .addComponent(winnerTable, javax.swing.GroupLayout.PREFERRED_SIZE, 274, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(86, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("FINALISE RESULTS", jPanel5);

        jLabel9.setBackground(new java.awt.Color(255, 0, 0));
        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel9.setText("ADMIN DASHBOARD");

        SIGNOUT.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        SIGNOUT.setText("SIGN OUT");
        SIGNOUT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SIGNOUTActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane2)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 261, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(123, 123, 123)
                .addComponent(SIGNOUT)
                .addGap(21, 21, 21))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(SIGNOUT)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(18, 18, 18)
                .addComponent(jTabbedPane2))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void SIGNOUTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SIGNOUTActionPerformed
        // TODO add your handling code here:
        Form_VM_System screen = new Form_VM_System();
        screen.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_SIGNOUTActionPerformed

    private void jTabbedPane2StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jTabbedPane2StateChanged

    }//GEN-LAST:event_jTabbedPane2StateChanged

    private void btn_clear_candidateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_clear_candidateActionPerformed
            id.setText("");
            cname.setText("");
            pname.setText("");
            cnic.setText("");
            age.setText("");
            uname.setText("");
            upass.setText("");
            
//            JOptionPane.showMessageDialog(null, "Cleared"); 
    }//GEN-LAST:event_btn_clear_candidateActionPerformed

    private void refreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshActionPerformed
        // TODO add your handling code here:
        jScrollPane2.setVisible(true);
        table.setVisible(true);
        ViewRecord view = new ViewRecord();
        view.view(table);
    }//GEN-LAST:event_refreshActionPerformed

    private void recordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_recordActionPerformed
        // TODO add your handling code here:
        record.setVisible(false);
        refresh.setVisible(true);
        jScrollPane2.setVisible(true);
        table.setVisible(true);
        ViewRecord view = new ViewRecord();
        view.view(table);
    }//GEN-LAST:event_recordActionPerformed

    private void btn_delete_candidateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_delete_candidateActionPerformed
        if (id.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Enter ID");
        }
        else{
            String ID = id.getText();
            int iD = Integer.parseInt(ID);
            cand.deleteRecord(iD);
        }        
    }//GEN-LAST:event_btn_delete_candidateActionPerformed

    private void btn_add_candidateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_add_candidateActionPerformed
        // TODO add your handling code here:
        if(cname.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Enter Candidate Name");
        }
        else if(pname.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Enter Candidate Party");
        }        
        else if(cnic.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Enter CNIC");
        }
        else if(age.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Enter Age");
        }
        else if(uname.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Enter UserName");
        }
        else if(upass.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Enter User Password");
        }
        
        else{
            String name = cname.getText();
            String partyname = pname.getText();
            String CNIC = cnic.getText();
            int Cnic = Integer.parseInt(CNIC);
            String AGE = age.getText();
            int Age = Integer.parseInt(AGE);
            String Uname = uname.getText();
            String Upass = upass.getText();
            
            boolean b=cand.accountCheck(Cnic);
        
            if(b){
                    JOptionPane.showMessageDialog(null, "Already Account Created");
            }
            else if(b==false){
                    cand.createCandidate(name, partyname, Cnic, Age, Uname, Upass);
            }
        }        
    }//GEN-LAST:event_btn_add_candidateActionPerformed

    private void cnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cnameActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_cnameActionPerformed

    private void doneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_doneActionPerformed
        if(on.isSelected()==true){
            boolean status=true;
            boolean b=adm.votingStatus(status);
            if(b==true){
                JOptionPane.showMessageDialog(null, "Voting ON");
            }
            else{
                JOptionPane.showMessageDialog(null, "Error");
            }
        }
        else if(off.isSelected()==true){
            boolean status=false;
            boolean b=adm.votingStatus(status);
            if(b==true){
                JOptionPane.showMessageDialog(null, "Voting OFF");
            }
            else{
                JOptionPane.showMessageDialog(null, "Error");
            }
        }

    }//GEN-LAST:event_doneActionPerformed

    private void offActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_offActionPerformed
        // TODO add your handling code here:
        on.setSelected(false);
        off.setSelected(true);
    }//GEN-LAST:event_offActionPerformed

    private void onActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_onActionPerformed
        // TODO add your handling code here:
        on.setSelected(true);
        off.setSelected(false);
        
    }//GEN-LAST:event_onActionPerformed

    private void recordMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_recordMouseClicked
        table.setVisible(true);
        ViewRecord view = new ViewRecord();
        view.view(table);
    }//GEN-LAST:event_recordMouseClicked

    private void idMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_idMouseClicked
        // TODO add your handling code here;       
    }//GEN-LAST:event_idMouseClicked

    private void idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idActionPerformed

    }//GEN-LAST:event_idActionPerformed

    private void btn_search_candidateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_search_candidateActionPerformed
        if (id.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Enter ID");
        }
        else if(id.getText().isEmpty()==false){
            try{
                int ID = Integer.parseInt(id.getText());
                boolean b = cand.findCandidate(ID);

                if(b){
                    cname.setText(cand.name);
                    pname.setText(cand.party);
                    cnic.setText(cand.Cnic);
                    age.setText(cand.Age);
                    uname.setText(cand.Uname);
                    upass.setText(cand.Upass);
                }

                else{
                    JOptionPane.showMessageDialog(null, "No Record Found");
                }
            }
            catch(NumberFormatException e){
                JOptionPane.showMessageDialog(null, "Not a Valid ID");
            }
        }
//        else{
//            int ID = Integer.parseInt(id.getText());
//            boolean b = cand.findCandidate(ID);
//
//            if(b){
//                cname.setText(cand.name);
//                pname.setText(cand.party);
//                cnic.setText(cand.Cnic);
//                age.setText(cand.Age);
//                uname.setText(cand.Uname);
//                upass.setText(cand.Upass);
//            }
//            
//            else{
//                JOptionPane.showMessageDialog(null, "No Record Found");
//            }
//        }
                
    }//GEN-LAST:event_btn_search_candidateActionPerformed

    private void RonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RonActionPerformed
        // TODO add your handling code here:
        Ron.setSelected(true);
        Roff.setSelected(false);
    }//GEN-LAST:event_RonActionPerformed

    private void RoffActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RoffActionPerformed
        // TODO add your handling code here:
        Ron.setSelected(false);
        Roff.setSelected(true);
    }//GEN-LAST:event_RoffActionPerformed

    private void rdoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdoneActionPerformed
        if(Ron.isSelected()==true){
            boolean status=true;
            boolean b=adm.candRegStatus(status);
            if(b==true){
                JOptionPane.showMessageDialog(null, "Candidate Registration Open");
            }
            else{
                JOptionPane.showMessageDialog(null, "Error");
            }
        }
        else if(Roff.isSelected()==true){
            boolean status=false;
            boolean b=adm.candRegStatus(status);
            if(b==true){
                JOptionPane.showMessageDialog(null, "Candidate Registration Close");
            }
            else{
                JOptionPane.showMessageDialog(null, "Error");
            }
        }
    }//GEN-LAST:event_rdoneActionPerformed

    private void winnerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_winnerActionPerformed
        adm.candRegStatus(false);
        adm.votingStatus(false);
        adm.Winner();
        
        winner.setVisible(false);
        winnerRefresh.setVisible(true);
        winnerTable.setVisible(true);
        tableWin.setVisible(true);
        ViewRecord view = new ViewRecord();
        view.view(tableWin);
    }//GEN-LAST:event_winnerActionPerformed

    private void btn_update_candidateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_update_candidateActionPerformed
        boolean b;
        
        if(cname.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Enter Candidate Name");
        }
        else if(pname.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Enter Party Name");
        }
        else if(cnic.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Enter CNIC");
        }
        else if(age.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Enter Age");
        }
        else if(id.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Enter ID");
        }
        else{
            b=cand.updateUser(cname.getText(), pname.getText(), Integer.parseInt(cnic.getText()), Integer.parseInt(age.getText()), Integer.parseInt(id.getText()));
            if(b==true){
                JOptionPane.showMessageDialog(null, "Updated");
            }
            else{
                JOptionPane.showMessageDialog(null, "Error");
            }
        }
    }//GEN-LAST:event_btn_update_candidateActionPerformed

    private void winnerRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_winnerRefreshActionPerformed
        // TODO add your handling code here:
        winner.setVisible(false);
        winnerRefresh.setVisible(true);
        winnerTable.setVisible(true);
        tableWin.setVisible(true);
        ViewRecord view = new ViewRecord();
        view.view(tableWin);
    }//GEN-LAST:event_winnerRefreshActionPerformed

    private void cnameKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cnameKeyTyped
        // TODO add your handling code here:
        char c=evt.getKeyChar();
        boolean check = false;
        
        if((c==KeyEvent.VK_BACK_SPACE)||  (c==KeyEvent.VK_DELETE )){
            check = true;
            if (check == true){
                    msg1.setVisible(false);
            }
        }
        
        else if(Character.isAlphabetic(c)){
            check = false;
            if (check == false){
                    msg1.setVisible(false);
            }
        }
        
        else if(check == false){
            if(!(Character.isAlphabetic(c))){                
                evt.consume();
                if (check == false){
                    msg1.setVisible(true);
                }
            }
        }        
    }//GEN-LAST:event_cnameKeyTyped

    private void pnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pnameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pnameActionPerformed

    private void pnameKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_pnameKeyTyped
        // TODO add your handling code here:
        char c=evt.getKeyChar();
        boolean check = false;
        
        if((c==KeyEvent.VK_BACK_SPACE)||  (c==KeyEvent.VK_DELETE )){
            check = true;
            if (check == true){
                    msg1.setVisible(false);
            }
        }
        
        else if(Character.isAlphabetic(c)){
            check = false;
            if (check == false){
                    msg1.setVisible(false);
            }
        }
        
        else if(check == false){
            if(!(Character.isAlphabetic(c))){                
                evt.consume();
                if (check == false){
                    msg1.setVisible(true);
                }
            }
        }        
    }//GEN-LAST:event_pnameKeyTyped

    private void cnicActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cnicActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cnicActionPerformed

    private void cnicKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cnicKeyTyped
        // TODO add your handling code here:
        char c=evt.getKeyChar();
        boolean check = false;
        
        if((c==KeyEvent.VK_BACK_SPACE)||  (c==KeyEvent.VK_DELETE )){
            check = true;
            if (check == true){
                    msg3.setVisible(false);
            }
        }
        
        else if(Character.isAlphabetic(c)){
            check = false;
            evt.consume();
            if (check == false){
                    msg3.setVisible(true);
            }
        }
        
        else if(!(Character.isDigit(c) )){
            check = false;
            evt.consume();
            if (check == false){
                    msg3.setVisible(true);
            }
        }
        
        else if(Character.isDigit(c)){
            check = true;
            if (check == true){
                    msg3.setVisible(false);
            }
        }    
    }//GEN-LAST:event_cnicKeyTyped

    private void ageKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ageKeyTyped
        // TODO add your handling code here:
        char c=evt.getKeyChar();
        boolean check = false;
        
        if((c==KeyEvent.VK_BACK_SPACE)||  (c==KeyEvent.VK_DELETE )){
            check = true;
            if (check == true){
                    msg3.setVisible(false);
            }
        }
        
        else if(Character.isAlphabetic(c)){
            check = false;
            evt.consume();
            if (check == false){
                    msg3.setVisible(true);
            }
        }
        
        else if(!(Character.isDigit(c))){
            check = false;
            evt.consume();
            if (check == false){
                    msg3.setVisible(true);
            }
        }
        
        else if(Character.isDigit(c)){
            check = true;
            if (check == true){
                    msg3.setVisible(false);
            }
        }  
    }//GEN-LAST:event_ageKeyTyped

    private void unameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_unameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_unameActionPerformed

    private void refreshCitizenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshCitizenActionPerformed
        // TODO add your handling code here:
        panelCitizen.setVisible(true);
        tableCitizen.setVisible(true);
        ViewRecord view = new ViewRecord();
        view.citizenTable(tableCitizen);
    }//GEN-LAST:event_refreshCitizenActionPerformed

    private void record1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_record1ActionPerformed
        // TODO add your handling code here:
        record1.setVisible(false);
        refreshCitizen.setVisible(true);
        panelCitizen.setVisible(true);
        tableCitizen.setVisible(true);
        ViewRecord view = new ViewRecord();
        view.citizenTable(tableCitizen);
    }//GEN-LAST:event_record1ActionPerformed

    private void record1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_record1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_record1MouseClicked

    private void btn_clear_citizenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_clear_citizenActionPerformed
        id1.setText("");
        citname.setText("");
        cnic1.setText("");
        age1.setText("");
        uname1.setText("");
        upass1.setText("");
        JOptionPane.showMessageDialog(null, "Cleared");
    }//GEN-LAST:event_btn_clear_citizenActionPerformed

    private void btn_search_citizenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_search_citizenActionPerformed
        if (id1.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Enter ID");
        }
        else if(id1.getText().isEmpty()==false){
            try{
                int ID = Integer.parseInt(id.getText());
                boolean b = citz.findCandidate(ID);

                if(b==true){
                    cnic1.setText(citz.Cnic);
                    age1.setText(citz.Age);
                    uname1.setText(citz.Uname);
                    upass1.setText(citz.Upass);
                    citname.setText(citz.name);
                }
                else{
                    JOptionPane.showMessageDialog(null, "No Record Found");
                }
            }catch(NumberFormatException e){
                JOptionPane.showMessageDialog(null, "Not a Valid ID");
            }
        }
        else{
            int ID = Integer.parseInt(id.getText());
            boolean b = citz.findCandidate(ID);

            if(b==true){
                cnic1.setText(citz.Cnic);
                age1.setText(citz.Age);
                uname1.setText(citz.Uname);
                upass1.setText(citz.Upass);
                citname.setText(citz.name);
            }
            else{
                JOptionPane.showMessageDialog(null, "No Record Found");
            }
        }
    }//GEN-LAST:event_btn_search_citizenActionPerformed

    private void btn_update_citizenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_update_citizenActionPerformed
        boolean b;
        if(citname.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Enter Citizen Name");
        }
        else if(cnic1.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Enter CNIC");
        }
        else if(age1.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Enter Age");
        }
        else if(id1.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Enter ID");
        }
        else{
            b=citz.updateUser(citname.getText(), Integer.parseInt(cnic1.getText()), Integer.parseInt(age1.getText()), Integer.parseInt(id1.getText()));
            if(b==true){
                JOptionPane.showMessageDialog(null, "Updated");
            }
            else{
                JOptionPane.showMessageDialog(null, "Error");
            }
        }

    }//GEN-LAST:event_btn_update_citizenActionPerformed

    private void btn_delete_citizenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_delete_citizenActionPerformed
        if (id1.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Enter ID");
        }
        else{
            String ID = id1.getText();
            int iD = Integer.parseInt(ID);
            citz.deleteRecord(iD);
        }
    }//GEN-LAST:event_btn_delete_citizenActionPerformed

    private void btn_add_citizenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_add_citizenActionPerformed
        if(citname.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Enter Citizen Name");
        }
        else if(cnic1.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Enter CNIC");
        }
        else if(age1.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Enter Age");
        }
        else if(uname1.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Enter UserName");
        }
        else if(upass1.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Enter User Password");
        }
        else{
            String name = citname.getText();
            String CNIC = cnic1.getText();
            int Cnic = Integer.parseInt(CNIC);
            String AGE = age1.getText();
            int Age = Integer.parseInt(AGE);
            String Uname = uname1.getText();
            String Upass = upass1.getText();

            boolean b=citz.accountCheck(Cnic);

            if(b==true){
                JOptionPane.showMessageDialog(null, "Already Account Created");
            }
            else if(b==false){
                b=citz.CheckEligibility(Age, Cnic);
                if(b==true){
                    b=citz.createCitizen(name, Cnic, Age, Uname, Upass);
                    if(b==true){
                        JOptionPane.showMessageDialog(null, "Account Successfully Created");
                    }
                    else{
                        JOptionPane.showMessageDialog(null, "Error");
                    }
                }
                else{
                    JOptionPane.showMessageDialog(null, "Not Eligible");
                }
            }
        }
    }//GEN-LAST:event_btn_add_citizenActionPerformed

    private void citnameKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_citnameKeyTyped
        // TODO add your handling code here:
        char c=evt.getKeyChar();

        if(!(Character.isAlphabetic(c))){
            evt.consume();
            JOptionPane.showMessageDialog(null, "Numbes Not Allowed");
        }
    }//GEN-LAST:event_citnameKeyTyped

    private void uname1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_uname1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_uname1ActionPerformed

    private void age1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_age1KeyTyped
        // TODO add your handling code here:
        char c=evt.getKeyChar();

        if(Character.isAlphabetic(c)){
            evt.consume();
            JOptionPane.showMessageDialog(null, "Text Not Allowed");
        }
    }//GEN-LAST:event_age1KeyTyped

    private void cnic1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cnic1KeyTyped
        // TODO add your handling code here:
        char c=evt.getKeyChar();

        if(Character.isAlphabetic(c)){
            evt.consume();
            JOptionPane.showMessageDialog(null, "Text Not Allowed");
        }
    }//GEN-LAST:event_cnic1KeyTyped

    private void id1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_id1ActionPerformed

    }//GEN-LAST:event_id1ActionPerformed

    private void id1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_id1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_id1MouseClicked

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Form_Admin_Dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Form_Admin_Dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Form_Admin_Dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Form_Admin_Dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Form_Admin_Dashboard().setVisible(true);                               
            }
        });
        
        
        

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton Roff;
    private javax.swing.JRadioButton Ron;
    private javax.swing.JButton SIGNOUT;
    private javax.swing.JTextField age;
    private javax.swing.JTextField age1;
    private javax.swing.JButton btn_add_candidate;
    private javax.swing.JButton btn_add_citizen;
    private javax.swing.JButton btn_clear_candidate;
    private javax.swing.JButton btn_clear_citizen;
    private javax.swing.JButton btn_delete_candidate;
    private javax.swing.JButton btn_delete_citizen;
    private javax.swing.JButton btn_search_candidate;
    private javax.swing.JButton btn_search_citizen;
    private javax.swing.JButton btn_update_candidate;
    private javax.swing.JButton btn_update_citizen;
    private javax.swing.JTextField citname;
    private javax.swing.JTextField cname;
    private javax.swing.JTextField cnic;
    private javax.swing.JTextField cnic1;
    private javax.swing.JButton done;
    private javax.swing.JTextField id;
    private javax.swing.JTextField id1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JLabel msg1;
    private javax.swing.JLabel msg2;
    private javax.swing.JLabel msg3;
    private javax.swing.JRadioButton off;
    private javax.swing.JRadioButton on;
    private javax.swing.JScrollPane panelCitizen;
    private javax.swing.JTextField pname;
    private javax.swing.JButton rdone;
    private javax.swing.JButton record;
    private javax.swing.JButton record1;
    private javax.swing.JButton refresh;
    private javax.swing.JButton refreshCitizen;
    private javax.swing.JTable table;
    private javax.swing.JTable tableCitizen;
    private javax.swing.JTable tableWin;
    private javax.swing.JTextField uname;
    private javax.swing.JTextField uname1;
    private javax.swing.JTextField upass;
    private javax.swing.JTextField upass1;
    private javax.swing.JButton winner;
    private javax.swing.JButton winnerRefresh;
    private javax.swing.JScrollPane winnerTable;
    // End of variables declaration//GEN-END:variables
}
