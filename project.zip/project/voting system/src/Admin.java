import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;
public class Admin {
    ConnectionToDB con=new ConnectionToDB();
    Connection con_obj=con.EstablishConnection();
    Statement stmt=null;//used for insert, update & delete
    PreparedStatement pstmt=null;//used for select
    ResultSet res=null;
    
    public boolean LoginUser(String chkuser,String chkpass){
        //select * from Table_Name where Column1='"+value+"'and Column2='"+value+"'....Col_n='"+value+"';
        String loginString="select * from AdminData where UName='"+chkuser+"' and UPass='"+chkpass+"'";
        boolean b;
        try{
            pstmt=con_obj.prepareStatement(loginString);
            res=pstmt.executeQuery();
            if(res.next()){
                b=true;
            }
            else{
                b=false;
            }
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null, ex);
            b=false;
        }
        return b;
    }
    
    public boolean votingStatus(boolean status){
        boolean pass=true;
        String updateString="UPDATE AdminData SET Voting_Open='"+status+"' WHERE ID='"+1+"'";
        try{   
            stmt=con_obj.createStatement();
            int res=stmt.executeUpdate(updateString);
            if(res>0){
                //JOptionPane.showMessageDialog(null, "Updated");
                pass=true;
            }
            else{
                //JOptionPane.showMessageDialog(null, "Error");
                pass=false;
            }
        }
        catch(Exception ex){
           JOptionPane.showMessageDialog(null, "Error");
        }
        return pass;
    }
    
    //candidate registration check
    public boolean candRegStatus(boolean status){
        boolean pass=true;
        String updateString="UPDATE AdminData SET Reg_Open='"+status+"' WHERE ID='"+1+"'";
        try{   
            stmt=con_obj.createStatement();
            int res=stmt.executeUpdate(updateString);
            if(res>0){
                //JOptionPane.showMessageDialog(null, "Updated");
                pass=true;
            }
            else{
                //JOptionPane.showMessageDialog(null, "Error");
                pass=false;
            }
        }
        catch(Exception ex){
           JOptionPane.showMessageDialog(null, "Error");
        }
        return pass;
    }
    
    //Calculating Winner of Elections
    public void Winner(){
        int[] win=new int[20];
        int id=1;
        int count=0;
        //select * from Table_Name where Column1='"+value+"'and Column2='"+value+"'....Col_n='"+value+"';
        String finalise="select * from CandidateData where ID='"+id+"'";
        boolean b = false;
        try{
            pstmt=con_obj.prepareStatement(finalise);
            res=pstmt.executeQuery();
            while(res.next()){
                win[count]=res.getInt("VoteCount");
                count+=1;
            }
        }
        catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex);
            b=false;
        }
        int winner_index=1;
        try{
            int winner = win[0];
            System.out.println(winner);
            for(int i=1;i<win.length;i++){
                if(win[i]>winner){
                    winner=win[i];
                    winner_index=i;
                }
            }
        }
        catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex);
        }
        System.out.println(winner_index);
        String winnerString="UPDATE CandidateData SET Winner='"+true+"' WHERE ID='"+(winner_index+1)+"'";
        try{   
            stmt=con_obj.createStatement();
            int res=stmt.executeUpdate(winnerString);
            if(res>0){
                JOptionPane.showMessageDialog(null, "Calculating...");
            }
            else{
                //JOptionPane.showMessageDialog(null, "Error");
            }
        }
        catch(Exception ex){
           JOptionPane.showMessageDialog(null, ex);
        }
    }
}
